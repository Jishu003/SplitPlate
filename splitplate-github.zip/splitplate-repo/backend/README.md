# SplitPlate — Backend (Firebase)

SplitPlate uses **Firebase Firestore** as its backend — a serverless NoSQL cloud database by Google. No custom server is needed.

---

## Firebase Project

| Field | Value |
|---|---|
| Project ID | `splitplat` |
| Console URL | https://console.firebase.google.com/project/splitplat |
| Database | Cloud Firestore (default) |
| Region | us-east1 (default) |

---

## Setup Steps

### 1. Apply Firestore Rules

In Firebase Console → **Firestore Database → Rules tab** → paste contents of `firestore.rules` → click **Publish**.

Or via Firebase CLI:
```bash
npm install -g firebase-tools
firebase login
firebase deploy --only firestore:rules
```

### 2. Apply Firestore Indexes (optional)

```bash
firebase deploy --only firestore:indexes
```

---

## Database Schema

```
Firestore
└── users/                          Collection
    └── {emailKey}/                 Document
        ├── uid: string
        ├── name: string
        ├── email: string
        ├── password: string        ← Plain text (demo only)
        ├── createdAt: timestamp
        ├── lastLogin: timestamp
        └── orders/                 Subcollection
            └── {orderId}/          Document
                ├── orderId: string
                ├── userEmail: string
                ├── userName: string
                ├── grandTotal: number
                ├── subtotal: number
                ├── deliveryFee: 40
                ├── platformFee: 8
                ├── tax: number
                ├── itemCount: number
                ├── orderState: "building"|"buffer"|"sent"
                ├── billPaidByOrganizer: boolean
                ├── restaurants: string[]
                ├── restaurantName: string
                ├── cart: object[]
                ├── cartByRestaurant: object
                ├── people: string[]
                ├── perPersonDetails: object
                ├── payState: object
                ├── refundState: object
                └── updatedAt: timestamp
```

---

## Email Key Convention

Firebase document IDs cannot contain `.` or `@`.
Emails are transformed:

```
jishu@gmail.com  →  jishu_at_gmail_com
anya@gmail.com   →  anya_at_gmail_com
```

```javascript
function emailKey(email) {
  return email.toLowerCase().trim()
    .replace(/\./g, '_')
    .replace(/@/g, '_at_');
}
```

---

## Firebase SDK (used in all 3 frontend files)

```html
<script src="https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore-compat.js"></script>
```

```javascript
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
```

---

## Production Recommendations

| Current (Demo) | Production |
|---|---|
| Plain text passwords | Firebase Authentication + hashed passwords |
| `allow read, write: if true` | Per-user auth rules |
| API key in client JS | Domain-restricted API key in GCP console |
| Admin password in JS source | Server-side session management |
